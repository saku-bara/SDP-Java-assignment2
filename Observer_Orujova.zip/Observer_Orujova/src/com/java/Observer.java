package com.java;
import java.util.List;

public interface Observer {
    void update(List<Integer> sits);
}
